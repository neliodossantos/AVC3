package Interface;

/**
 * Interface para representar uma Transação.
 */
public interface Transacao {
    void executar();
}


