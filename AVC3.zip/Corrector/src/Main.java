/**
 * Cadeira - Algoritmo e Complexidade
 * @Autor Nelio dos Santos
 * 2 Exercicio
 */

// importando os pacotes da pasta Entidade
import Entity.CarteiraTitulos;
import Entity.Cliente;
import Entity.Corretor;
import Entity.TituloParticipacao;
import java.time.LocalDate;

/**
 * Classe Principal.
 */
public class Main {
    public static void main(String[] args) {

        // Obtendo a data atual
        LocalDate data = LocalDate.now();

        // Criando um corretor
        Corretor corretor = new Corretor(1, "João", data, "123456789", 3000.0);

        // Criando um cliente
        Cliente cliente = new Cliente("Maria", 1, "987654321", "Rua A");

        // Criando títulos de participação
        TituloParticipacao titulo1 = new TituloParticipacao("Titulo1", data, 100.0);
        TituloParticipacao titulo2 = new TituloParticipacao("Titulo2", data, 150.0);

        // Criando uma carteira de títulos
        CarteiraTitulos carteira = new CarteiraTitulos(corretor, cliente, 10);

        // Adicionando títulos à carteira
        carteira.adicionarTitulo(titulo1, 5);
        carteira.adicionarTitulo(titulo2, 3);

        // Removendo um título da carteira
        carteira.removerTitulo(titulo1);

        // Exibindo informações da carteira
        System.out.println("Corretor: " + corretor.getNome());
        System.out.println("Cliente: " + cliente.getNome());
        System.out.println("Títulos na carteira:");

        // Obtendo os títulos e quantidades da carteira
        TituloParticipacao[] titulos = carteira.getTitulos();
        int[] quantidadesTitulos = carteira.getQuatidade();
        // Iterando sobre os títulos na carteira e exibindo suas informações
        for (int i = 0; i < carteira.getTamanhoActual(); i++) {
            System.out.println("Título: " + titulos[i] +
                    ", Quantidade: " + quantidadesTitulos[i]);
        }
    }
}
