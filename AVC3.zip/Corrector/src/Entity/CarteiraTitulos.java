package Entity;
import Interface.Carteira;
/**
 * Classe que representa uma Carteira de Títulos de Participação.
 */
public class CarteiraTitulos implements Carteira {
    private Corretor corretorResponsavel;
    private Cliente clienteAssociado;
    private TituloParticipacao[] titulos;
    private int quatidade [];
    private static int tamanhoActual;

    /**
     * Construtor da classe CarteiraTitulos.
     */
    public CarteiraTitulos(Corretor corretorResponsavel, Cliente clienteAssociado , int quantidadeMax) {
        this.corretorResponsavel = corretorResponsavel;
        this.clienteAssociado = clienteAssociado;
        this.titulos = new TituloParticipacao[100];
        this.quatidade = new int[quantidadeMax];
        this.tamanhoActual = 0;
    }

    public int getTamanhoActual() {
        return tamanhoActual;
    }

    public void setTamanhoActual(int tamanhoActual) {
        CarteiraTitulos.tamanhoActual = tamanhoActual;
    }

    @Override
    public void adicionarTitulo(TituloParticipacao titulo, int quantidade) {
        // Implementação do método adicionarTitulo
    }

    @Override
    public void removerTitulo(TituloParticipacao titulo) {
        // Implementação do método removerTitulo
    }

    public Cliente getClienteAssociado() {
        return clienteAssociado;
    }

    public void setClienteAssociado(Cliente clienteAssociado) {
        this.clienteAssociado = clienteAssociado;
    }

    public Corretor getCorretorResponsavel() {
        return corretorResponsavel;
    }

    public void setCorretorResponsavel(Corretor corretorResponsavel) {
        this.corretorResponsavel = corretorResponsavel;
    }

    public TituloParticipacao[] getTitulos() {
        return titulos;
    }

    public void setTitulos(TituloParticipacao[] titulos) {
        this.titulos = titulos;
    }

    public int[] getQuatidade() {
        return quatidade;
    }

    public void setQuatidade(int[] quatidade) {
        this.quatidade = quatidade;
    }
}

