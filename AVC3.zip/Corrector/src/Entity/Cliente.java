package Entity;
/**
 * Classe que representa um Cliente.
 */
public class Cliente {
        private String nome;
        private int numero;
        private String telefone;
        private String endereco;

        /**
         * Construtor da classe Cliente.
         */
        public Cliente(String nome, int numero, String telefone, String endereco) {
                this.nome = nome;
                this.numero = numero;
                this.telefone = telefone;
                this.endereco = endereco;
        }

        public String getNome() {
                return nome;
        }

        public void setNome(String nome) {
                this.nome = nome;
        }

        public int getNumero() {
                return numero;
        }

        public void setNumero(int numero) {
                this.numero = numero;
        }

        public String getTelefone() {
                return telefone;
        }

        public void setTelefone(String telefone) {
                this.telefone = telefone;
        }

        public String getEndereco() {
                return endereco;
        }

        public void setEndereco(String endereco) {
                this.endereco = endereco;
        }

}
