package Entity;

import Interface.Transacao;
import java.time.LocalDate;

/**
 * Classe que representa uma Ordem de Transação.
 */
class Ordem implements Transacao {
    private String tipo;
    private TituloParticipacao titulo;
    private int quantidade;
    private double valorTransacionado;
    private LocalDate dataHora;

    /**
     * Construtor da classe Ordem.
     */
    public Ordem(String tipo, TituloParticipacao titulo, int quantidade, double valorTransacionado, LocalDate dataHora) {
        // Implementação do construtor
    }

    // Métodos getters e setters para os atributos
    // Implemente conforme necessário

    @Override
    public void executar() {
        // Implementação do método executar
    }
}
