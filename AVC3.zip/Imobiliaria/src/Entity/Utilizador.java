package Entity;

// Classe base para todos os utilizadores do sistema
public abstract class Utilizador {
    protected String nome;
    protected String email;
    protected String senha;

    // Método para realizar login
    public abstract boolean fazerLogin(String email, String senha);

    // Método para registar um novo utilizador
    public abstract void registar(String nome, String email, String senha);
}
