package Entity;
import Interface.Imovel;

// Classe abstrata para representar propriedades imobiliárias
abstract class Propriedade implements Imovel {
    protected int anoConstrucao;
    protected double area;
    protected String localizacao;

    // Construtor
    public Propriedade(int anoConstrucao, double area, String localizacao) {
        this.anoConstrucao = anoConstrucao;
        this.area = area;
        this.localizacao = localizacao;
    }
}
