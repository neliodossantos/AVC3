package Entity;

public class Proprietario extends Utilizador {

    private boolean pedidoRegistroAprovado;
    public Proprietario(String nome, String email, String password) {
        this.nome = nome;
        this.email = email;
        this.senha = password;
        this.pedidoRegistroAprovado = false; // Pedido de registro inicialmente não aprovado
    }
    @Override
    public boolean fazerLogin(String email, String senha) {
        return false;
    }

    @Override
    public void registar(String nome, String email, String senha) {

    }
}
