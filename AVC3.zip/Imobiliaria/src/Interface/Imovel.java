package Interface;

// Interface para imóveis
public interface Imovel {
    void exibirDetalhes();
}
