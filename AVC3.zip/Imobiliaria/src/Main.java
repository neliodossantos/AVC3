import Entity.Apartamento;
import Entity.Terreno;
import Entity.Vivenda;

public class Main {
    public static void main(String[] args) {

    // Criar alguns imóveis
    Apartamento apartamento = new Apartamento(2000, 100, "Centro", "T2", 150000);
    Vivenda vivenda = new Vivenda(1995, 200, "Periferia", "T3", 300000);
    Terreno terreno = new Terreno(2020, 500, "Subúrbio", true);

    // Exibir detalhes dos imóveis
    System.out.println("Detalhes do Apartamento:");
    apartamento.exibirDetalhes();
    System.out.println();

    System.out.println("Detalhes da Vivenda:");
    vivenda.exibirDetalhes();
    System.out.println();

    System.out.println("Detalhes do Terreno:");
    terreno.exibirDetalhes();



    }
}