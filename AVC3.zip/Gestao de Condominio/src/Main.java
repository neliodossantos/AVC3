/**
 * Cadeira - Algoritmo e Complexidade
 * @Autor Nelio dos Santos
 * 2 Exercicio
 */

// Importando os pacotes da pasta Entidade
import Entity.*;

public class Main {
    public static void main(String[] args) {

        // Criação de instâncias de Condominio
        Condominio c1 = new Condominio("Zango","Luanda,Cazenga");
        Condominio c2 = new Condominio("Kilamba","Luanda,Cazenga");

        // Criação de instâncias de Edificio
        Edificio ed1C1  = new Edificio("A",c1);
        Edificio ed2C1  = new Edificio("B",c1);
        Edificio ed3C1  = new Edificio("C",c1);

        Edificio ed1C2  = new Edificio("X",c2);
        Edificio ed2C2  = new Edificio("Y",c2);

        // Criação de instâncias de Apartamento
        Apartamento ap1C1 = new Apartamento(1,ed1C1);
        Apartamento ap2C1 = new Apartamento(2,ed1C1);
        Apartamento ap3C1 = new Apartamento(3,ed1C1);

        Apartamento ap1C2 = new Apartamento(1,ed1C2);

        // Criação de instâncias de Condomino
        Condomino cd1  = new Condomino("Nelio" , ap1C1);
        Condomino cd2  = new Condomino("Ana", ap1C1);
        Condomino cd3  = new Condomino("Matheus", ap1C2);

        // Adicionando edifícios, apartamentos e condôminos aos condomínios
        c1.adicionarEdificio(ed1C1);
        c1.adicionarEdificio(ed2C1);
        c1.adicionarEdificio(ed3C1);

        c1.adicionarApartamento(ap1C1);
        c1.adicionarApartamento(ap2C1);
        c1.adicionarApartamento(ap3C1);

        c1.adicionarCondominio(cd1);
        c1.adicionarCondominio(cd2);

        c2.adicionarEdificio(ed1C2);
        c2.adicionarEdificio(ed2C2);
        c2.adicionarApartamento(ap1C2);
        c2.adicionarCondominio(cd3);

        // Listando informações dos condomínios
        c1.listar();
        c2.listar();

        System.out.println("------------------------------------------------");

        // Adicionando despesas comuns ao edifício 1 do condomínio 1
        DespesasComuns despesasComunsEd1 = new DespesasComuns("Agua",3200,ed1C1);
        ed1C1.adicionarDespesasComuns(despesasComunsEd1);

        System.out.println("------------------------------------------------");

        // Listando despesas comuns do edifício 1 do condomínio 1
        ed1C1.listarDespesasComuns();
    }
}
