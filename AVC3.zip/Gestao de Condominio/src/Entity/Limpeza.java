package Entity;

public class Limpeza extends Funcionario {
    private int bonus;
    public Limpeza(String nome , double salarioBase , int bonus){
        super(nome,salarioBase);
        this.bonus = bonus;
    }
    @Override
    public double calcularSalario() {
        return super.calcularSalario() + bonus;
    }
}
