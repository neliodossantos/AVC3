package Entity;

public class Servicos extends Base {
    private String nome;
    private String tipo;

}
