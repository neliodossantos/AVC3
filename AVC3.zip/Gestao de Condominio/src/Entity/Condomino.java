package Entity;

public class Condomino extends Base {
    private String nome;
    private static int totalCondomino;
    private  Apartamento apartamento;
    private Conta conta;



    public Condomino(String nome , Apartamento apartamento){
        this.nome = nome;
        this.apartamento = apartamento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTotalCondomino() {
        return totalCondomino;
    }
    public void setTotalCondomino(int totalCondomino) {
        Condomino.totalCondomino = totalCondomino;
    }

    public Apartamento getApartamento() {
        return apartamento;
    }

    public void setApartamento(Apartamento apartamento) {
        this.apartamento = apartamento;
    }
}
