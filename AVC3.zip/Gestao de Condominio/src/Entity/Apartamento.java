package Entity;

public class Apartamento  extends Base {
    private int numeroApartamento;
    private Edificio edificio;
    private static int totalApartamento;


    public Apartamento(int numeroApartamento , Edificio edificio ){
        this.numeroApartamento = numeroApartamento;
        this.edificio = edificio;
    }
    public int getNumeroApartamento() {
        return numeroApartamento;
    }
    public void setNumeroApartamento(int numeroApartamento) {
        this.numeroApartamento = numeroApartamento;
    }

    public Edificio getEdificio() {
        return edificio;
    }
    public void setEdificio(Edificio edificio) {
        this.edificio = edificio;
    }

    public int getTotalApartamento() {
        return totalApartamento;
    }
    public  void setTotalApartamento(int totalApartamento) {
        this.totalApartamento = totalApartamento;
    }

}
