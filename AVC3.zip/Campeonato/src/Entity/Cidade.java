package Entity;

// Entidade para representar uma cidade
public class Cidade {
        private String nome;
        // Outros atributos e métodos relevantes
        public Cidade(String nome) {
            this.nome = nome;
        }
}
