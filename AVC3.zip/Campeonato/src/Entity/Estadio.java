package Entity;

public class Estadio {
    // Entidade para representar um estádio
    private String nome;
    private Cidade cidade;
    // Outros atributos e métodos relevantes
    public Estadio(String nome, Cidade cidade) {
        this.nome = nome;
        this.cidade = cidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
