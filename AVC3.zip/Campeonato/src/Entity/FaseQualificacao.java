package Entity;


public class FaseQualificacao {
    // Entidade para representar a fase de qualificação
    private Grupo [] grupos;

    public FaseQualificacao() {
        this.grupos = new Grupo[100];
    }

    public void adicionarGrupo(Grupo grupo) {
        int total = grupo.getTotalGrupo();
        grupos[total++] = grupo;
        if(total<100){
            grupos[total++] = grupo;
            grupo.setTotalGrupo(total);
        }else{
            System.out.println("Erro nao pode adicionar");
        }
    }
}
