/**
 * Cadeira - Algoritmo e Complexidade
 * @Autor Nelio dos Santos
 * 2 Exercicio
 */

// importando os pacotes da pasta Entidade
import Entity.*;

// Classe principal Main
public class Main {
    public static void main(String[] args) {
        // Instanciando países
        Pais portugal = new Pais("Portugal");
        Pais argentina = new Pais("Argentina");

        // Instanciando seleções
        Selecao selecaoPortugal = new Selecao("Portugal", portugal);
        Selecao selecaoArgentina = new Selecao("Argentina", argentina);

        // Instanciando jogadores
        Jogador jogador1 = new Jogador("Lionel Messi", 36,"Avançado",10);
        selecaoPortugal.adicionarJogador(jogador1);

        // Instanciando estádios e cidades
        Cidade lisboa = new Cidade("Lisboa");
        Estadio estadioLuz = new Estadio("Estádio da Luz", lisboa);

        // Instanciando a fase de qualificação
        FaseQualificacao faseQualificacao = new FaseQualificacao();
        Grupo grupoA = new Grupo("Grupo A");
        grupoA.adicionarSelecao(selecaoPortugal);
        grupoA.adicionarSelecao(selecaoArgentina);
        faseQualificacao.adicionarGrupo(grupoA);

        // Instanciando um jogo
        Jogo jogo1 = new Jogo(selecaoPortugal, selecaoArgentina, 2, 1);

        // Exibindo informações do jogo
        System.out.println("Jogo 1:");
        System.out.println("Estadio " + estadioLuz.getNome());
        System.out.println("Casa: " + jogo1.getTimeCasa().getNome());
        System.out.println("Visitante: " + jogo1.getTimeVisitante().getNome());
        System.out.println("Placar Casa: " + jogo1.getPlacarCasa());
        System.out.println("Placar Visitante: " + jogo1.getPlacarVisitante());

    }
}